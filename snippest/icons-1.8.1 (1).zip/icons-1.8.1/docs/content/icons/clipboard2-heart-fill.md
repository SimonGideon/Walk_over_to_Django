---
title: Clipboard2 heart fill
categories:
  - Real world
tags:
  - copy
  - paste
---
