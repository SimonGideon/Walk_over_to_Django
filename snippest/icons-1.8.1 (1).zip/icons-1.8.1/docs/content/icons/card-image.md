---
title: Card image
categories:
  - Files and folders
tags:
  - note
  - card
  - notecard
---
