---
title: Chat text fill
categories:
  - Communications
tags:
  - chat bubble
  - text
  - message
---
