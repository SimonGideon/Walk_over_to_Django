---
title: Clipboard2 plus
categories:
  - Real world
tags:
  - copy
  - paste
---
