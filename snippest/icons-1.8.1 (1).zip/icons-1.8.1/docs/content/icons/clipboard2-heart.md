---
title: Clipboard2 heart
categories:
  - Real world
tags:
  - copy
  - paste
---
